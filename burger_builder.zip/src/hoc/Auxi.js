const Auxi = (props) => props.children

export default Auxi;